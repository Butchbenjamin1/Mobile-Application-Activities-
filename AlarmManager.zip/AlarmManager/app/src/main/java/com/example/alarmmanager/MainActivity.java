package com.example.alarmmanager;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PRIMARY_CHANNEL_ID = "stand_up_notification_channel";
    private static final int NOTIFICATION_ID = 0;

    private NotificationManager mNotificationManager;
    private AlarmManager mAlarmManager;
    private PendingIntent notifyPendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ToggleButton alarmToggle = findViewById(R.id.alarmToggle);

        // Set up the NotificationManager
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();

        // Create the intent and PendingIntent for AlarmReceiver
        Intent notifyIntent = new Intent(this, AlarmReceiver.class);
        notifyPendingIntent = PendingIntent.getBroadcast(
                this,
                NOTIFICATION_ID,
                notifyIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Check if the alarm is already active
        boolean alarmUp = (PendingIntent.getBroadcast(
                this,
                NOTIFICATION_ID,
                notifyIntent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE) != null);

        // Set the toggle button state
        alarmToggle.setChecked(alarmUp);

        // Set up the AlarmManager
        mAlarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        // Handle toggle button changes
        alarmToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            String toastMessage;

            if (isChecked) {
                long repeatInterval = AlarmManager.INTERVAL_FIFTEEN_MINUTES;
                long triggerTime = SystemClock.elapsedRealtime() + repeatInterval;

                if (mAlarmManager != null) {
                    mAlarmManager.setInexactRepeating(
                            AlarmManager.ELAPSED_REALTIME_WAKEUP,
                            triggerTime,
                            repeatInterval,
                            notifyPendingIntent
                    );
                }

                toastMessage = "Alarm On";
            } else {
                if (mAlarmManager != null) {
                    mAlarmManager.cancel(notifyPendingIntent);
                }
                mNotificationManager.cancelAll();
                toastMessage = "Alarm Off";
            }

            Toast.makeText(MainActivity.this, toastMessage, Toast.LENGTH_SHORT).show();
        });
    }

    /**
     * Creates a NotificationChannel required for API 26+ devices
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    PRIMARY_CHANNEL_ID,
                    "Stand Up! Notification",
                    NotificationManager.IMPORTANCE_HIGH
            );
            notificationChannel.enableVibration(true);
            notificationChannel.setDescription("Notifies every 15 minutes to stand up and walk");

            mNotificationManager.createNotificationChannel(notificationChannel);
        }
    }
}
